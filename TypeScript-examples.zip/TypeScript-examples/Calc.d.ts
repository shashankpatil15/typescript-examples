export declare namespace math {
    class Calc {
        add(a: number, b: number): number;
    }
}

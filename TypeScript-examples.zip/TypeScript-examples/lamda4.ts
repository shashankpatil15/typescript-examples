var disp =()=> console.log("Function invoked"); 

disp();
import {Company} from "./company";

var c=new Company();


c.id=101;
c.name="Softedge";
c.address="Aundh";

console.log(c.id,c.name,c.address);










"use strict";
exports.__esModule = true;
var Triangle = (function () {
    function Triangle() {
    }
    Triangle.prototype.draw = function () {
        console.log("Triangle is drawn");
    };
    return Triangle;
}());
exports.Triangle = Triangle;

export interface IShape{
draw(); //public abstract
}

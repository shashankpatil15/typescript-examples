
export class Calc{

public add(a:number,b:number):number{
return a+b;
}


}


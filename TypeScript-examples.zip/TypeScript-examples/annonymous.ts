var msg = function() { 
   return "hello world";  
} 


console.log(msg())




function hello(a:number){
return a+100;
}


console.log(hello(10));


var x=y=>(x,y)=>{x+y
return 
};


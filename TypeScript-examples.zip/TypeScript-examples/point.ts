class Point {
    x: number;
    y: number;
}

interface Point3d extends Point {
    z: number;
}

let point3d: Point3d = {x: 1, y: 2, z: 3};

console.log("x ="+point3d.x);
console.log("y ="+point3d.y);
console.log("z ="+point3d.z);



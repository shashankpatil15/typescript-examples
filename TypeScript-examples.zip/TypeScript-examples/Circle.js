"use strict";
exports.__esModule = true;
var Circle = (function () {
    function Circle() {
    }
    Circle.prototype.draw = function () {
        console.log("Circle is drawn");
    };
    return Circle;
}());
exports.Circle = Circle;

var foo = (x:number)=>{return 10 + x;} 
var foo1 =(x)=>10 + x; 
var foo2 =x=>10 + x; 




console.log(foo(100))      //outputs 110 
console.log(foo1(100))      //outputs 110 
console.log(foo2(100))      //outputs 110 


var display = x=> { 
   console.log("The function got "+x) 
} 

var display1 = (x,y)=> { 
    console.log("The function got "+x+","+y) 
 } 
 
 display(12)
 display1(12,"pradeep");
 
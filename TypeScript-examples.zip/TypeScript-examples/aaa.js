"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Book = (function () {
    function Book() {
    }
    Object.defineProperty(Book.prototype, "id", {
        get: function () {
            console.log("In get Id " + this._id);
            return this._id;
        },
        set: function (id) {
            this._id = id;
            console.log("In set Id " + id);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Book.prototype, "name", {
        get: function () {
            console.log("In get Name " + this._name);
            return this._name;
        },
        set: function (name) {
            this._name = name;
            console.log("In set Name " + name);
        },
        enumerable: true,
        configurable: true
    });
    return Book;
}());
exports.Book = Book;

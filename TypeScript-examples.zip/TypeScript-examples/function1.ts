var myFunction = new Function("a", "b","c", "return a * b* c") 
var x = myFunction(4,3,4);console.log(x)
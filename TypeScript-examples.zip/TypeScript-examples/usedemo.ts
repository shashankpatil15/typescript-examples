
import {Emp} from "./demo";

var e=new Emp();

console.log("Id   :"+e.id);
console.log("Name :"+e.name);
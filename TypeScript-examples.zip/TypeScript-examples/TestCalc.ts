import {Calc} from "./Calc";

var c=new Calc();

console.log(c.add(10,20));

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var aaa_1 = require("./aaa");
var b1 = new aaa_1.Book();
b1.id = 101; //set id
b1.name = "Java"; //set name
console.log(b1.id, b1.name); //get id  get name

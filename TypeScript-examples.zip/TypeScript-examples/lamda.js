var foo1 = function (x) { return 10 + x; };
var foo2 = function (x) { return 10 + x; };
var foo3 = function (x) { return 10 + x; };
var foo4 = function (x) { return (10 + x); };
var disp1 = function () { return console.log("Function invoked"); };
var display = function (x) { console.log("The function got " + x); };
var displayAdd = function (x, y) { console.log("The function got " + x); };
var func = function (x) {
    if (typeof x == "number")
        console.log(x + " is numeric");
    else if (typeof x == "string")
        console.log(x + " is a string");
};
console.log(foo1(100)); //outputs 110 
console.log(foo2(100)); //outputs 110 
console.log(foo3(100)); //outputs 110 
console.log(foo4(100)); //outputs 110 
display(12);
disp1();
func(12);
func("Tom");
console.log(displayAdd(34, 45));

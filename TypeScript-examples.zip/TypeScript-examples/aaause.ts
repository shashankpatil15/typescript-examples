import {Book} from "./aaa";


var b1=new Book();


b1.id=101;  //set id
b1.name="Java"; //set name

console.log(b1.id,b1.name);  //get id  get name

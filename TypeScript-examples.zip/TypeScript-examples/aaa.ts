export class Book{
private _id:number;
private _name:string;


set id(id:number){
    this._id=id;
    console.log("In set Id "+id);

}

set name(name:string){
    this._name=name;
    console.log("In set Name "+name);
    
}

get id():number{
    console.log("In get Id "+this._id);
    
    return this._id;
}

get name():string{
    console.log("In get Name "+this._name);
    
    return this._name;
}

}

















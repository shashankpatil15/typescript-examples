


export class Emp{
id:number=101;
name:string="pradeep";


}
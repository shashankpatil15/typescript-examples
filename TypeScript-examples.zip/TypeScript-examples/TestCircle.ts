/// <reference path="Circle.ts" />

var circleShape=new Drawing.Circle();
circleShape.draw();
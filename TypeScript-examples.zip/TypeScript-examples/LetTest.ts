
for(var i=0;i<10;i++)
console.log(i);

console.log("After  for loop : var i "+i)
console.log("=====================");


for(let j=0;j<10;j++)
console.log(j);

console.log("After  for loop : j "+j)
//console.log("=====================");
